<?php

    $conect=mysqli_connect("localhost", "phpmyadminuser", "fb56b44dbb", "base_ip");
    $con='SELECT * FROM ip_encontrar';
    $datos=mysqli_query($conect, $con);
    $ip1 = mysqli_fetch_all($datos, MYSQLI_ASSOC);


    $con2='SELECT * FROM ip_insert';
    $datos2 = mysqli_query($conect, $con2);
    $ip2 = mysqli_fetch_all($datos2, MYSQLI_ASSOC);

    $id= 1;
    $i = 0;
?>
<?php foreach ($ip1 as $ip){?>
  <tr style="width:680px;">
    <td style="width:40px;"><?php echo $id;$id++ ?></td>
    <td style="width:187px;"><?php echo $ip["edificio"]; ?></td>
    <td style="width:120px;"><?php echo $ip["ip"]; ?></td>
    <td style="width:230px;">
      <?php
          if ($ip["ip"] == $ip2[$i]["ip"]) {
            echo "Asignada";
          }else {
            echo "No Asignada";
          }

        $i++;
      ?>
    </td>
      <td style="width:290px;"><button type="button" onclick = "javascript:abrir()" class="btn btn-danger btn-rounded"><a>Informacion</a></button> </td>
    <td style="width:130px;">
      <?php
          $i--;
          echo $ip2[$i]["tipo_ip"];
          $i++;
      ?>
    </td>
    <td style="width:250px;">
      <?php
            $i--;
            echo $ip2[$i]["fecha_asignacion"];
            $i++;
      ?>
    </td>
  </tr>

<?php } ?>
    <script src="assets/js/cerrar_abrir.js"></script>
