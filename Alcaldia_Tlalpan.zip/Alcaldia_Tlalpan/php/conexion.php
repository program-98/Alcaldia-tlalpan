<?php
  $con=mysqli_connect("localhost","phpmyadminuser","fb56b44dbb","base_ip");


 ?>
