<?php
$conection=mysqli_connect('localhost','phpmyadminuser','fb56b44dbb','ip');
$segmento=$_POST['area_edi'];

	$sql="SELECT id,
			 id_sec,
			 secmento
		from sec_ip
		where id_sec='$segmento'";

	$result=mysqli_query($conection,$sql);

	$cadena="<h2>Segmentos</h2>
			<select id='lista2' name='seg' style='border-radius: 10px;'>";

	while ($ver=mysqli_fetch_row($result)) {
		$cadena=$cadena.'<option value='.utf8_encode($ver[2]).'>'.utf8_encode($ver[2]).'</option>';
	}

	echo  $cadena."</select>";
?>
