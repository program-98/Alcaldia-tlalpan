function abrir(){
  document.getElementById("alert").style.display="block";
}
function cerrar(){
    document.getElementById("alert").style.display="none";
}
