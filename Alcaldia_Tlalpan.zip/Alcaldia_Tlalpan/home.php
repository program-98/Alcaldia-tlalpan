<?php
session_start();


	if (isset($_POST['submit'])) {
		$conn=mysqli_connect('localhost','phpmyadminuser','fb56b44dbb','usuarios');
		$user = $_POST["usuario"];
		$contrasena = $_POST["contrasena"];
		$_SESSION['usuario1']=$user;
		$sql='SELECT * FROM login';
		$query=mysqli_query($conn, $sql);
    $usuarios = mysqli_fetch_all($query, MYSQLI_ASSOC);


					foreach ($usuarios as $usuario) {

						if ($usuario["tipo_user"] == "SuperUsuario") {
							if ($_SESSION['usuario1'] == $usuario["user"] && $contrasena == $usuario["password"]) {
								header("Location:tabla_superuser.php");
							}
						}else if ($usuario["tipo_user"] == "Administrador") {
							if ($_SESSION['usuario1'] == $usuario["user"] && $contrasena == $usuario["password"]) {
								header("Location: tabla_admin.php");
							}
						}else if ($usuario["tipo_user"] == "Tecnico") {
              if ($_SESSION['usuario1'] == $usuario["user"] && $contrasena == $usuario["password"]){
                  header("Location: tabla_tec.php");
              }
            }
            }
          }



 ?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!--- Include the above in your HEAD tag --->


<!DOCTYPE html>
<html>
<head>
	<title>Alcaldia Tlalpan</title>
   <!--Made with love by Mutiullah Samim -->
   <link rel="shortcut icon" href="preters/img/logo_alcaldia.png" type="image/png">
	<!--Bootsrap 4 CDN-->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <!--Fontawesome CDN-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

	<!--Custom styles-->
	<link rel="stylesheet" type="text/css" href="assets/css/csslogin.css">
</head>
<body>
<div class="container">
	<div class="d-flex justify-content-center h-100">
    <div class="card">
			<div class="card-header">
        <img src="preters/img/logo_alcaldia.png " width="130px" alt="" style="margin-left:120px; margin-bottom:10px;">
				<h3 class="text-center">Inicio de Sesion</h3>
				<div class="d-flex justify-content-end ">

				</div>
			</div>
			<div class="card-body">
				<form method="POST">
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fas fa-user"></i></span>
						</div>
						<input id="usuario" type="text" class="form-control" placeholder="Usuario" name="usuario">

					</div>
					<div class="input-group form-group">
						<div class="input-group-prepend">
							<span class="input-group-text"><i class="fas fa-key"></i></span>
						</div>
						<input id="contrasena" type="password" class="form-control" placeholder="Contraseña" name="contrasena">
					</div>
					<div class="form-group">
						<input type="submit" value="Login" class="btn float-right login_btn" name="submit">
					</div>
				</form>
			</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>
