<?php

session_start();

$varsession=$_SESSION['usuario1'];
if ($varsession == null || $varsession='') {
  header("Location:home.php");
  die();
}

require('php/conexion.php');




if (isset($_POST['guardar'])) {

    $i=0;
    $edificio=$_POST['edificio'];
    $ip=$_POST['ip'];
    $secmento=$_POST['seg'];
    $user_pc=$_POST['user_pc'];
    $serie=$_POST['serie'];
    $no_inv=$_POST['no_inv'];
    $adscripcion=$_POST['adscripcion'];
    $tipo_ip=$_POST['tipo_ip'];
    $fullIp = $secmento.$ip;

    $sql3='SELECT * FROM ip_insert';
    $data= mysqli_query($con, $sql3);
    $ipl = mysqli_fetch_all($data, MYSQLI_ASSOC);

    $consult="INSERT INTO ip_insert(edificios, ip, user_pc, serie, no_inv, adscripcion, tipo_ip) VALUES ('$edificio',
                                                                                                         '$fullIp',
                                                                                                         '$user_pc',
                                                                                                         '$serie',
                                                                                                         '$no_inv',
                                                                                                         '$adscripcion',
                                                                                                         '$tipo_ip')";


    if( $ipl[$i]["ip"] == $fullIp) {
      echo "<script language='JavaScript' type='text/javascript'> alert('Ip Duplicada');</script> ";
    }else{
        $res8=mysqli_query($con, $consult);
    }
$i++;
}
?>
<!DOCTYPE html>
<html lang='es' dir='ltr'>
  <head>
  <link rel='stylesheet' href='assets/Bootstrap/css/bootstrap.min.css'>
    <link rel='shortcut icon' href='preters/img/logo_alcaldia.png' type="image/png">
    <link rel="stylesheet" href="assets/css/styles.css">
    <script src='assets/Alertify/alertify.js'></script>
    <script type='text/javascript' src='assets/Bootstrap/js/bootstrap.min.js'></script>
    <script src='https://code.jquery.com/jquery-3.3.1.min.js'
  	integrity='sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8='
  	crossorigin='anonymous'></script>
    <meta charset='utf-8'>
    <title>Alcaldia Tlalpan</title>
  </head>
  <body onpageshow='return false' oncontextmenu='return false'>

    <header>
      <nav class='navbar navbar-dark fixed-top' >
        <a class="navbar-brand" href="#">
          <img src="preters/img/logo_alcaldia.png" height="40" class="d-inline-block align-top"
            alt="Alcaldia Tlalpan"> Tecnologia de la Infomacion y Comunicaciones
        </a>
        <a href="tabla_superuser.php"><button class="btn btn-outline-success my-2 my-sm-0" type="button" id="btn_in">Regresar</button></a>
      </nav>
    </header>


  <div id="wrap">
    <form  method="POST">
        <section id="wrap">
          <div id="edi_area">
          <h2>Edificios de la Alcaldia</h2>
            <select id="lista1" name="edificio" style="border-radius: 10px;">
              <option value="0">Selecciona una opcion</option>
              <option value="1">Vivanco</option>
              <option value="2">Tlalpan Centro</option>
              <option value="3">Desarrollo Social</option>
              <option value="4">Juarez</option>
              <option value="5">Casa Frisac</option>
              <option value="6">Museo de Tlalpan</option>
              <option value="7">Servicios Urbanos</option>
              <option value="8">Congreso 50 B</option>
              <option value="9">Congreso 50 A</option>
              <option value="10">Matamoros</option>
              <option value="11">Casa de la caultura</option>
            </select>
          </div>
          <div id="segmento_ip"></div>
          <div id="ip">
            <h2>Ip</h2>
            <select id="#lista3" name="ip" style="border-radius: 10px; width:57px; text_align:center;">
              <option value="">Selecciona tu ip</option>
              <?php for ($i=1; $i < 256 ; $i++) {
                echo "<option value='$i'>$i</option>";
              } ?>
        </select>
          </div>
          <div id="tecnico_user">

            <h2>Tecnico</h2 >
            <label for="" value="<?php echo $_SESSION['usuario1']; ?>" ><?php echo $_SESSION['usuario1']; ?></label>
          </div>
        <div id="ip_tipo">
          <h2>Tipo de Ip</h2>
          <select id="tipo_ip" name="tipo_ip" style="border-radius: 10px;">
            <option value=""></option>
            <option value="Fija">Fija</option>
            <option value="Servidor">Servidor</option>
            <option value="Temporal">Temporal</option>
            <option value="Impresoras">Imperesoras</option>
          </select>
        </div>

        <div id="ip_user">
          <h2>Nombre del usuario</h2>
          <input type="text" name="user_pc" value="" style="text-align:center; font-family:sans-serif; font-size:20px;">
        </div>
        <div id="ip_serie">
          <h2>Serie</h2>
          <input type="text" name="serie" value="" style="text-align:center; font-family:sans-serif; font-size:20px;">
        </div>
        <div id="ip_noinv">
            <h2>No. inventario</h2>
            <input type="text" name="no_inv" value=""  style="text-align:center; font-family:sans-serif; font-size:20px;">
        </div>
        <div id="ip_adscripcion">
          <h2>Adscripcion</h2>
          <select name="adscripcion"  style="border-radius: 10px; text_align:center;">
                           <option value="">Selecciona una Area</option>
                           <option value="Secretaría  Particular"> Secretaría  Particular </option>
                           <option value="Coordinador de Asesores"> Coordinador de Asesores </option>
                           <option value="Asesor A"> Asesor A </option>
                           <option value="Asesor B"> Asesor B </option>
                           <option value="Dirección del Centro de Servicios y Atención Ciudadana"> Dirección del Centro de Servicios y Atención Ciudadana </option>
                           <option value="Enlace de Información y Seguimiento a Solicitudes de Servicios A"> Enlace de Información y Seguimiento a Solicitudes de Servicios A </option>
                           <option value="Enlace de Información y Seguimiento a Solicitudes de Servicios B"> Enlace de Información y Seguimiento a Solicitudes de Servicios B </option>
                           <option value="Enlace de Atención a la Ciudadanía A"> Enlace de Atención a la Ciudadanía A </option>
                           <option value="Enlace de Atención a la Ciudadania B"> Enlace de Atención a la Ciudadania B </option>
                           <option value="Enlace de Atención a la Ciudadanía C"> Enlace de Atención a la Ciudadanía C </option>
                           <option value="Enlace de Atención a la Ciudadanía D"> Enlace de Atención a la Ciudadanía D </option>
                           <option value="Dirección Jurídica"> Dirección Jurídica </option>
                           <option value="dirección de Procedimientos Contenciosos"> Subdirección de Procedimientos Contenciosos </option>
                           <option value="J.U.D. de Contratos Convenios y Permisos en Materia Administrativa"> J.U.D. de Contratos Convenios y Permisos en Materia Administrativa </option>
                           <option value="J.U.D. de Juzgados Civicos, Registro Civil y Junta de Reclutamiento del Servicio Militar Nacional"> J.U.D. de Juzgados Civicos, Registro Civil y Junta de Reclutamiento del Servicio Militar Nacional </option>
                           <option value="Subdirección de Verificación y Reglamentos"> Subdirección de Verificación y Reglamentos </option>
                           <option value="J.U.D. de Apoyo Legal"> J.U.D. de Apoyo Legal </option>
                           <option value="J.U.D. de Ejecución de Sanciones"> J.U.D. de Ejecución de Sanciones </option>
                           <option value="Subdirección de Calificación de Infracciones"> Subdirección de Calificación de Infracciones </option>
                           <option value="J.U.D. de Establecimientos Mercantiles y de Construcción"> J.U.D. de Establecimientos Mercantiles y de Construcción </option>
                           <option value="Dirección de Gobierno"> Dirección de Gobierno </option>
                           <option value="Subdirección de Gobierno"> Subdirección de Gobierno </option>
                           <option value="J.U.D. de Mercados y Concentraciones"> J.U.D. de Mercados y Concentraciones </option>
                           <option value="J.U.D. de Tianguis y Vía Pública"> J.U.D. de Tianguis y Vía Pública </option>
                           <option value="J.U.D. de Giros Mercantiles y Espectáculos Públicos"> J.U.D. de Giros Mercantiles y Espectáculos Públicos </option>
                           <option value="J.U.D. de Panteones"> J.U.D. de Panteones </option>
                           <option value="Dirección de Ordenamiento Territorial"> Dirección de Ordenamiento Territorial </option>
                           <option value="J.U.D. de Colonias y Asentamientos Humános Irregulares"> J.U.D. de Colonias y Asentamientos Humános Irregulares </option>
                           <option value="J.U.D. de Regularización Territorial"> J.U.D. de Regularización Territorial </option>
                           <option value="Dirección de Seguridad Ciudadana"> Dirección de Seguridad Ciudadana </option>
                           <option value="Enlace de Atención a Peticiones en Materia de Seguridad"> Enlace de Atención a Peticiones en Materia de Seguridad </option>
                           <option value="Subdirección de Información y Control"> Subdirección de Información y Control </option>
                           <option value="J.U.D. de Información y Estadistica"> J.U.D. de Información y Estadistica </option>
                           <option value="Dirección General de Administración"> Dirección General de Administración </option>
                           <option value="Dirección de Modernización Administrativa de Tecnologías de la Información y comunicaciones"> Dirección de Modernización Administrativa de Tecnologías de la Información y comunicaciones </option>
                           <option value="J.U.D. de Modernización Administrativa"> J.U.D. de Modernización Administrativa </option>
                           <option value="Subdirección de Tecnologías de la Información y Comunicaciones"> Subdirección de Tecnologías de la Información y Comunicaciones </option>
                           <option value="J.U.D. de Desarrollo de Sistemas"> J.U.D. de Desarrollo de Sistemas </option>
                           <option value="J.U.D. de Soporte Técnico"> J.U.D. de Soporte Técnico </option>
                           <option value="Dirección de Capital Humano"> Dirección de Capital Humano </option>
                           <option value="Subdirección de Relaciones Laborales y capacitación"> Subdirección de Relaciones Laborales y capacitación </option>
                           <option value="J.U.D. de Relaciones Laborales y Prestaciones"> J.U.D. de Relaciones Laborales y Prestaciones </option>
                           <option value="J.U.D. de Capacitación y Desarrollo de Personal"> J.U.D. de Capacitación y Desarrollo de Personal </option>
                           <option value="J.U.D. de Registro y Movimientos de Personal"> J.U.D. de Registro y Movimientos de Personal </option>
                           <option value="J.U.D. de Nominas y Pagos"> J.U.D. de Nominas y Pagos </option>
                           <option value="Dirección de Recursos Financieros y Presupuestales"> Dirección de Recursos Financieros y Presupuestales </option>
                           <option value="Subdirección de Recursos Financieros"> Subdirección de Recursos Financieros </option>
                           <option value="J.U.D. de Contabilidad"> J.U.D. de Contabilidad </option>
                           <option value="Subdirección de PresupuestoSubdirección de Presupuesto"> Subdirección de Presupuesto </option>
                           <option value="J.U.D. de Programación y Control Presupuestal"> J.U.D. de Programación y Control Presupuestal </option>
                           <option value="Dirección de Recursos Materiales y Servicios Generales"> Dirección de Recursos Materiales y Servicios Generales </option>
                           <option value="J.U.D. de Adquisiciones"> J.U.D. de Adquisiciones </option>
                           <option value="J.U.D. de Almacenes e Inventarios"> J.U.D. de Almacenes e Inventarios </option>
                           <option value="Subdirección de Servicios Generales"> Subdirección de Servicios Generales </option>
                           <option value="J.U.D. de Servicios Generales y Apoyo Logistíco"> J.U.D. de Servicios Generales y Apoyo Logistíco </option>
                           <option value="Líder Coordinador de Proyectos de Atención a Servicios Generales"> Líder Coordinador de Proyectos de Atención a Servicios Generales </option>
                           <option value="Líder Coordinador de Proyectos de Apoyo Logístico"> Líder Coordinador de Proyectos de Apoyo Logístico </option>
                           <option value="J.U.D. de Control Vehicular, Talleres y Combustible"> J.U.D. de Control Vehicular, Talleres y Combustible </option>
                           <option value="Líder Coordinador de Proyectos de Mantenimiento Vehicular"> Líder Coordinador de Proyectos de Mantenimiento Vehicular </option>
                           <option value="Líder Coordinador de Proyectos de Control de Combustible"> Líder Coordinador de Proyectos de Control de Combustible </option>
                           <option value="Dirección General de Obras y Desarrollo Urbano"> Dirección General de Obras y Desarrollo Urbano </option>
                           <option value="Líder Coordinador de Proyectos de Seguimiento a Solicitudes Especificas de Obra"> Líder Coordinador de Proyectos de Seguimiento a Solicitudes Especificas de Obra </option>
                           <option value="Enlace de Seguimiento e Informes de Obra"> Enlace de Seguimiento e Informes de Obra </option>
                           <option value="Dirección de Obras y Operación"> Dirección de Obras y Operación </option>
                           <option value="Subdirección de Obras"> Subdirección de Obras </option>
                           <option value="J.U.D. de Mantenimiento a Edificios Públicos"> J.U.D. de Mantenimiento a Edificios Públicos </option>
                           <option value="J.U.D. de Obras Viales"> J.U.D. de Obras Viales </option>
                           <option value="J.U.D. de Control de Materiales y Equipo"> J.U.D. de Control de Materiales y Equipo </option>
                           <option value="J.U.D. de Construcción de Edificios Públicos"> J.U.D. de Construcción de Edificios Públicos </option>
                           <option value="J.U.D. de Mantenimiento Menor"> J.U.D. de Mantenimiento Menor </option>
                           <option value="Enlace de Trabajos de Mantenimiento por Administración"> Enlace de Trabajos de Mantenimiento por Administración </option>
                           <option value="J.U.D. de Planteles Educativos"> J.U.D. de Planteles Educativos </option>
                           <option value="Líder Coordinador de Proyectos de Seguimiento de Infraestructura en Planteles Educativos"> Líder Coordinador de Proyectos de Seguimiento de Infraestructura en Planteles Educativos </option>
                           <option value="Subdirección de Operación Hidráulica"> Subdirección de Operación Hidráulica </option>
                           <option value="J.U.D. de Construcción de Obras para Saneamiento y Drenaje"> J.U.D. de Construcción de Obras para Saneamiento y Drenaje </option>
                           <option value="J.U.D. de Obras Hidráulicas"> J.U.D. de Obras Hidráulicas </option>
                           <option value="J.U.D. de Operación de Agua, Saneamiento y Drenaje A"> J.U.D. de Operación de Agua, Saneamiento y Drenaje A </option>
                           <option value="J.U.D. de Operación de Agua, Saneamiento y Drenaje B"> J.U.D. de Operación de Agua, Saneamiento y Drenaje B </option>
                           <option value="J.U.D. de Agua Potable en Pipas"> J.U.D. de Agua Potable en Pipas </option>
                           <option value="Dirección de Desarrollo Urbano"> Dirección de Desarrollo Urbano </option>
                           <option value="Subdirección de Permisos, Manifestaciones y Licencias"> Subdirección de Permisos, Manifestaciones y Licencias </option>
                           <option value="J.U.D. de Manifestaciones y Licencias de Construcción"> J.U.D. de Manifestaciones y Licencias de Construcción </option>
                           <option value="J.U.D. de Alineamientos y Números Oficiales"> J.U.D. de Alineamientos y Números Oficiales </option>
                           <option value="Dirección de Planeación y Control"> Dirección de Planeación y Control </option>
                           <option value="Subdirección Técnica Operativa"> Subdirección Técnica Operativa </option>
                           <option value="J.U.D. de Proyectos"> J.U.D. de Proyectos </option>
                           <option value="J.U.D. de Concursos de Obras"> J.U.D. de Concursos de Obras </option>
                           <option value="Subdirección de Administración de Obras"> Subdirección de Administración de Obras </option>
                           <option value="J.U.D. de Contratos"> J.U.D. de Contratos </option>
                           <option value="J.U.D. de Control y Avance Financiero"> J.U.D. de Control y Avance Financiero </option>
                           <option value="Dirección General de Servicios Urbanos"> Dirección General de Servicios Urbanos </option>
                           <option value="Líder Coordinador de Proyectos de Análisis"> Líder Coordinador de Proyectos de Análisis </option>
                           <option value="Líder Coordinador de Proyectos de Información"> Líder Coordinador de Proyectos de Información </option>
                           <option value="Dirección de Proyectos y Programas de Servicios Urbanos"> Dirección de Proyectos y Programas de Servicios Urbanos </option>
                           <option value="Subdirección de Mejoramiento Urbano"> Subdirección de Mejoramiento Urbano </option>
                           <option value="J.U.D. de Conservación de la Imagen Urbana"> J.U.D. de Conservación de la Imagen Urbana </option>
                           <option value="J.U.D. de Parques y JardinesJ.U.D. de Parques y Jardines"> J.U.D. de Parques y Jardines </option>
                           <option value="J.U.D. de Instalación y Mantenimiento de Luminarias"> J.U.D. de Instalación y Mantenimiento de Luminarias </option>
                           <option value="J.U.D. de Mejoramiento de Pueblos"> J.U.D. de Mejoramiento de Pueblos </option>
                           <option value="Subdirección de Limpia"> Subdirección de Limpia </option>
                           <option value="J.U.D. de Sistemas Básicos de Recolección"> J.U.D. de Sistemas Básicos de Recolección </option>
                           <option value="J.U.D. de Sistemas Mecanizados"> J.U.D. de Sistemas Mecanizados </option>
                           <option value="Dirección General de Desarrollo Social"> Dirección General de Desarrollo Social </option>
                           <option value="Líder Coordinador de Proyectos de Sistematización A"> Líder Coordinador de Proyectos de Sistematización A </option>
                           <option value="Líder Coordinador de Proyectos de Sistematización B"> Líder Coordinador de Proyectos de Sistematización B </option>
                           <option value="J.U.D. de Atención a Escuelas y Comunidades Escolares de Tlalpan"> J.U.D. de Atención a Escuelas y Comunidades Escolares de Tlalpan </option>
                           <option value="J.U.D. de Educación a Distancia"> J.U.D. de Educación a Distancia </option>
                           <option value="J.U.D. de Vinculación con  Instituciones Educativas"> J.U.D. de Vinculación con  Instituciones Educativas </option>
                           <option value="Dirección de Salud"> Dirección de Salud </option>
                           <option value="Subdirección de Atención a la Salud"> Subdirección de Atención a la Salud </option>
                           <option value="J.U.D. de Prevención a Adicciones"> J.U.D. de Prevención a Adicciones </option>
                           <option value="Subdirección de Promoción a la Salud y Protección Animal"> Subdirección de Promoción a la Salud y Protección Animal </option>
                           <option value="Líder Coordinador de Proyectos de Difusión de Planes y Programas Sociales"> Líder Coordinador de Proyectos de Difusión de Planes y Programas Sociales </option>
                           <option value="Líder Coordinador de Proyectos de Promoción"> Líder Coordinador de Proyectos de Promoción </option>
                           <option value="Líder Coordinador de Proyectos de Seguimiento y Registros"> Líder Coordinador de Proyectos de Seguimiento y Registros </option>
                           <option value="J.U.D. de Atención a la Población Adulta Mayor"> J.U.D. de Atención a la Población Adulta Mayor </option>
                           <option value="J.U.D. de Atención a la Juventud e Infancia"> J.U.D. de Atención a la Juventud e Infancia </option>
                           <option value="J.U.D. de Atención a los Grupos Vulnerables"> J.U.D. de Atención a los Grupos Vulnerables </option>
                           <option value="J.U.D. de Promoción Deportiva"> J.U.D. de Promoción Deportiva </option>
                           <option value="J.U.D. de Centros Deportivos"> J.U.D. de Centros Deportivos </option>
                           <option value="Dirección General de Medio Ambiente y Desarrollo Sustentable"> Dirección General de Medio Ambiente y Desarrollo Sustentable </option>
                           <option value="Líder Coordinador de Proyectos Seguimiento y Atención a Acuerdos"> Líder Coordinador de Proyectos Seguimiento y Atención a Acuerdos </option>
                           <option value="Subdirección de Información y Seguimiento Geográfico"> Subdirección de Información y Seguimiento Geográfico </option>
                           <option value="Dirección de Recursos Naturales y Desarrollo Rural"> Dirección de Recursos Naturales y Desarrollo Rural </option>
                           <option value="J.U.D. de Recursos Naturales"> J.U.D. de Recursos Naturales </option>
                           <option value="Enlace de Proyectos Productivos Sustentables"> Enlace de Proyectos Productivos Sustentables </option>
                           <option value="J.U.D. de Desarrollo Rural"> J.U.D. de Desarrollo Rural </option>
                           <option value="Enlace de Prácticas Agroambientales"> Enlace de Prácticas Agroambientales </option>
                           <option value="Dirección de Ordenamiento Ecológico y Educación Ambiental"> Dirección de Ordenamiento Ecológico y Educación Ambiental </option>
                           <option value="Enlace de Seguimiento a Programas y Proyectos"> Enlace de Seguimiento a Programas y Proyectos </option>
                           <option value="J.U.D. de Educación Ambiental"> J.U.D. de Educación Ambiental </option>
                           <option value="J.U.D. de Vigilancia e Impacto Ambiental"> J.U.D. de Vigilancia e Impacto Ambiental </option>
                           <option value="J.U.D de Ordenamiento Ecológico"> J.U.D de Ordenamiento Ecológico </option>
                           <option value="Enlace de Ordenamiento Ecológico y Vigilancia Ambiental"> Enlace de Ordenamiento Ecológico y Vigilancia Ambiental </option>
                           <option value="Líder Coordinador de Proyectos de Atención y Seguimiento"> Líder Coordinador de Proyectos de Atención y Seguimiento </option>
                           <option value="J.U.D. de Promoción Turística"> J.U.D. de Promoción Turística </option>
                           <option value="Subdirección de Relación con los Pueblos Originarios"> Subdirección de Relación con los Pueblos Originarios </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Pueblos A"> Enlace de Participación y Gestión Ciudadana en Pueblos A </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Pueblos B"> Enlace de Participación y Gestión Ciudadana en Pueblos B </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Pueblos C"> Enlace de Participación y Gestión Ciudadana en Pueblos C </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Pueblos D"> Enlace de Participación y Gestión Ciudadana en Pueblos D </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Pueblos E"> Enlace de Participación y Gestión Ciudadana en Pueblos E </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Pueblos F"> Enlace de Participación y Gestión Ciudadana en Pueblos F </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Pueblos G"> Enlace de Participación y Gestión Ciudadana en Pueblos G </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Pueblos H"> Enlace de Participación y Gestión Ciudadana en Pueblos H </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Pueblos I"> Enlace de Participación y Gestión Ciudadana en Pueblos I </option>
                           <option value="Subdirección de Vinculación y Fomento a la Participación Ciudadana A"> Subdirección de Vinculación y Fomento a la Participación Ciudadana A </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias A1"> Enlace de Participación y Gestión Ciudadana en Colonias A1 </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias A2"> Enlace de Participación y Gestión Ciudadana en Colonias A2 </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias A3"> Enlace de Participación y Gestión Ciudadana en Colonias A3 </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias A4"> Enlace de Participación y Gestión Ciudadana en Colonias A4 </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias A5"> Enlace de Participación y Gestión Ciudadana en Colonias A5 </option>
                           <option value="Subdirección de Vinculación y Fomento a la Participación Ciudadana B"> Subdirección de Vinculación y Fomento a la Participación Ciudadana B </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias B1"> Enlace de Participación y Gestión Ciudadana en Colonias B1 </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias B2"> Enlace de Participación y Gestión Ciudadana en Colonias B2 </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias B3"> Enlace de Participación y Gestión Ciudadana en Colonias B3 </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias B4"> Enlace de Participación y Gestión Ciudadana en Colonias B4 </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias B5"> Enlace de Participación y Gestión Ciudadana en Colonias B5 </option>
                           <option value="Subdirección de Vinculación y Fomento a la Participación Ciudadana C"> Subdirección de Vinculación y Fomento a la Participación Ciudadana C </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias C1"> Enlace de Participación y Gestión Ciudadana en Colonias C1 </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias C2"> Enlace de Participación y Gestión Ciudadana en Colonias C2 </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias C3"> Enlace de Participación y Gestión Ciudadana en Colonias C3 </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias C4"> Enlace de Participación y Gestión Ciudadana en Colonias C4 </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias C5"> Enlace de Participación y Gestión Ciudadana en Colonias C5 </option>
                           <option value="Subdirección de Vinculación y Fomento a la Participación Ciudadana D"> Subdirección de Vinculación y Fomento a la Participación Ciudadana D </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias D1"> Enlace de Participación y Gestión Ciudadana en Colonias D1 </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias D2"> Enlace de Participación y Gestión Ciudadana en Colonias D2 </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias D3"> Enlace de Participación y Gestión Ciudadana en Colonias D3 </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias D4"> Enlace de Participación y Gestión Ciudadana en Colonias D4 </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias D5"> Enlace de Participación y Gestión Ciudadana en Colonias D5 </option>
                           <option value="Líder Coordinador de Proyectos de Patrimonio Cultural"> Líder Coordinador de Proyectos de Patrimonio Cultural </option>
                           <option value="J.U.D. de Recintos Culturales"> J.U.D. de Recintos Culturales </option>
                           <option value="J.U.D. de Cultura Comunitaria"> J.U.D. de Cultura Comunitaria </option>
                           <option value="Alcaldía de Tlalpan"> Alcaldía de Tlalpan </option>
                           <option value="Subdirección de Control de Gestión"> Subdirección de Control de Gestión </option>
                           <option value="Asesor c"> Asesor c </option>
                           <option value="Subdirección de Atención Ciudadana"> Subdirección de Atención Ciudadana </option>
                           <option value="Jefatura de Unidad Departamental de Verificación y Suspensiones"> Subdirección de Ventanilla Única Delegacional  </option>
                           <option value="Dirección de Comunicación Social"> Dirección de Comunicación Social </option>
                           <option value="Líder Coordinador de Proyectos de Servicios Digitales"> Líder Coordinador de Proyectos de Servicios Digitales </option>
                           <option value="Jefatura de Unidad Departamental de Comunicación"> Jefatura de Unidad Departamental de Comunicación </option>
                           <option value="Jefatura de Unidad Departamental de Difusión"> Jefatura de Unidad Departamental de Difusión </option>
                           <option value="Dirección General de Asuntos Jurídicos y de Gobierno"> Dirección General de Asuntos Jurídicos y de Gobierno </option>
                           <option value="Jefatura de Unidad Departamental de Amparos"> Jefatura de Unidad Departamental de Amparos </option>
                           <option value="Jefatura de Unidad Departamental de Asuntos Civiles y Mercantiles"> Jefatura de Unidad Departamental de Asuntos Civiles y Mercantiles </option>
                           <option value="Jefatura de Unidad Departamental de Contratos Convenios y Permisos en Materia  Administrativa"> Jefatura de Unidad Departamental de Contratos Convenios y Permisos en Materia  Administrativa </option>
                           <option value="Jefatura de Unidad Departamental Contencioso Administrativo"> Jefatura de Unidad Departamental Contencioso Administrativo </option>
                           <option value="Jefatura de Unidad Departamental de Transparencia  y Derechos Humanos"> Jefatura de Unidad Departamental de Transparencia  y Derechos Humanos </option>
                           <option value="Subdirección de Asuntos Laborales"> Subdirección de Asuntos Laborales </option>
                           <option value="Jefatura de Unidad Departamental de Verificación y Suspensiones"> Jefatura de Unidad Departamental de Verificación y Suspensiones </option>
                           <option value="Jefatura de Unidad Departamental de Asuntos Penales"> Jefatura de Unidad Departamental de Asuntos Penales </option>
                           <option value="Enlace de Atención de Solicitudes en Vía Pública"> Enlace de Atención de Solicitudes en Vía Pública </option>
                           <option value="Jefatura de Unidad Departamental de Conservación del Uso del Suelo"> Jefatura de Unidad Departamental de Conservación del Uso del Suelo </option>
                           <option value="Jefatura de Unidad Departamental de Padrón Inmobiliario y Vivienda Irregulares"> Jefatura de Unidad Departamental de Padrón Inmobiliario y Vivienda Irregulares </option>
                           <option value="Jefatura de Unidad Departamental de Control Operativo"> Jefatura de Unidad Departamental de Control Operativo </option>
                           <option value="Jefatura de Unidad Departamental de Seguridad Ciudadana y Tránsito"> Jefatura de Unidad Departamental de Seguridad Ciudadana y Tránsito </option>
                           <option value="Subdirección de Cumplimiento y Auditorías"> Subdirección de Cumplimiento y Auditorías </option>
                           <option value="Jefatura de Unidad Departamental de Seguimiento de Gestión"> Jefatura de Unidad Departamental de Seguimiento de Gestión </option>
                           <option value="Líder Coordinador de Proyectos de Análisis y Emisión de Opiniones Técnicas"> Líder Coordinador de Proyectos de Análisis y Emisión de Opiniones Técnicas </option>
                           <option value="Dirección de Tesorería y Autogenerados"> Dirección de Tesorería y Autogenerados </option>
                           <option value="Subdirección de Autogenerados"> Subdirección de Autogenerados </option>
                           <option value="Enlace de Seguimiento e Informes"> Enlace de Seguimiento e Informes </option>
                           <option value="Líder Coordinador de Proyectos de Supervisión de Entrega de Servicios de Agua Potable y Pipas"> Líder Coordinador de Proyectos de Supervisión de Entrega de Servicios de Agua Potable y Pipas </option>
                           <option value="Jefatura de Unidad Departamental de Seguimiento a Auditorias de Obra Pública"> Jefatura de Unidad Departamental de Seguimiento a Auditorias de Obra Pública </option>
                           <option value="Dirección de Protección Civil"> Dirección de Protección Civil </option>
                           <option value="Líder Coordinador de Proyectos de Prevención y Mitigación de Riesgos"> Líder Coordinador de Proyectos de Prevención y Mitigación de Riesgos </option>
                           <option value="Jefatura de Unidad Departamental de Dictaminación de Riesgos"> Jefatura de Unidad Departamental de Dictaminación de Riesgos </option>
                           <option value="Jefatura de Unidad Departamental de Respuesta a Emergencias"> Jefatura de Unidad Departamental de Respuesta a Emergencias </option>
                           <option value="Enlace de Brigadas de Acción Zona I"> Enlace de Brigadas de Acción Zona I </option>
                           <option value="Enlace de Brigadas de Acción Zona II"> Enlace de Brigadas de Acción Zona II </option>
                           <option value="Enlace de Brigadas de Acción  Zona III"> Enlace de Brigadas de Acción  Zona III </option>
                           <option value="Enlace  de Brigadas de Acción  Zona IV"> Enlace  de Brigadas de Acción  Zona IV </option>
                           <option value="Enlace de Brigadas de Acción  Zona V"> Enlace de Brigadas de Acción  Zona V </option>
                           <option value="Subdirección de ordenamiento urbano y Movilidad"> Subdirección de ordenamiento urbano y Movilidad </option>
                           <option value="Líder Coordinador de Proyectos de Movilidad"> Líder Coordinador de Proyectos de Movilidad </option>
                           <option value="Dirección de Economía Solidaria y Desarrollo y Fomento Económico"> Dirección de Economía Solidaria y Desarrollo y Fomento Económico </option>
                           <option value="Jefatura de Unidad Departamental de Desarrollo Económico"> Jefatura de Unidad Departamental de Desarrollo Económico </option>
                           <option value="Jefatura de Unidad Departamental de Economía Solidaria y Promoción Cooperativa"> Jefatura de Unidad Departamental de Economía Solidaria y Promoción Cooperativa </option>
                           <option value="Dirección Ejecutiva de Derechos Culturales, Educativos, Deportivos"> Dirección Ejecutiva de Derechos Culturales, Educativos, Deportivos </option>
                           <option value="Coordinador de Educación"> Coordinador de Educación </option>
                           <option value="Enlace de Atención a Centros de Aprendizaje Virtual A"> Enlace de Atención a Centros de Aprendizaje Virtual A </option>
                           <option value="Enlace de Atención a Centros de Aprendizaje Virtual B"> Enlace de Atención a Centros de Aprendizaje Virtual B </option>
                           <option value="Enlace de Atención a Centros de Aprendizaje Virtual C"> Enlace de Atención a Centros de Aprendizaje Virtual C </option>
                           <option value="Enlace de Atención a Centros de Aprendizaje Virtual D"> Enlace de Atención a Centros de Aprendizaje Virtual D </option>
                           <option value="Enlace de Atención a Centros de Aprendizaje Virtual E"> Enlace de Atención a Centros de Aprendizaje Virtual E </option>
                           <option value="Enlace de Atención a Centros de Aprendizaje Virtual F"> Enlace de Atención a Centros de Aprendizaje Virtual F </option>
                           <option value="Enlace de Atención a Centros de Aprendizaje Virtual G "> Enlace de Atención a Centros de Aprendizaje Virtual G </option>
                           <option value="Enlace de Atención a Centros de Aprendizaje Virtual H"> Enlace de Atención a Centros de Aprendizaje Virtual H </option>
                           <option value="Enlace de Atención a Centros de Aprendizaje Virtual I"> Enlace de Atención a Centros de Aprendizaje Virtual I </option>
                           <option value="Enlace de Atención a Centros de Aprendizaje Virtual J"> Enlace de Atención a Centros de Aprendizaje Virtual J </option>
                           <option value="Coordinación de Desarrollo de Actividades Deportivas"> Coordinación de Desarrollo de Actividades Deportivas </option>
                           <option value="Coordinación de Cultura"> Coordinación de Cultura </option>
                           <option value="Subdirección de Promoción Cultural y Recintos Culturales"> Subdirección de Promoción Cultural y Recintos Culturales </option>
                           <option value="Jefatura de Unidad Departamental de Eventos Públicos, Promoción Artística y Cultural"> Jefatura de Unidad Departamental de Eventos Públicos, Promoción Artística y Cultural </option>
                           <option value="Subdirección de Coordinación de Centros de Arte y Oficios"> Subdirección de Coordinación de Centros de Arte y Oficios </option>
                           <option value="Enlace de Centro de Arte y Oficios A"> Enlace de Centro de Arte y Oficios A </option>
                           <option value="Enlace de Centro de Arte y Oficios B"> Enlace de Centro de Arte y Oficios B </option>
                           <option value="Enlace de Centro de Arte y Oficios C"> Enlace de Centro de Arte y Oficios C </option>
                           <option value="Enlace de Centro de Arte y Oficios D"> Enlace de Centro de Arte y Oficios D </option>
                           <option value="Enlace de Centro de Arte y Oficios E"> Enlace de Centro de Arte y Oficios E </option>
                           <option value="Dirección de Fomento a la Equidad de Género, e Igualdad Sustantiva"> Dirección de Fomento a la Equidad de Género, e Igualdad Sustantiva </option>
                           <option value="Jefatura de Unidad Departamental de Igualdad Sustantiva"> Jefatura de Unidad Departamental de Igualdad Sustantiva </option>
                           <option value="Dirección de Atención a Grupos Vulnerables "> Dirección de Atención a Grupos Vulnerables </option>
                           <option value="Jefatura de Unidad Departamental de Atención a la Población LGBTII"> Jefatura de Unidad Departamental de Atención a la Población LGBTII </option>
                           <option value="Jefatura de Unidad Departamental de Centros de Desarrollo Comunitario Integral"> Jefatura de Unidad Departamental de Centros de Desarrollo Comunitario Integral </option>
                           <option value="Jefatura de Unidad Departamental de Atención a Personas con Discapacidad"> Jefatura de Unidad Departamental de Atención a Personas con Discapacidad </option>
                           <option value="Dirección General de Participación Ciudadana y Prevención del Delito"> Dirección General de Participación Ciudadana y Prevención del Delito </option>
                           <option value="Subdirección de Programas y Proyectos de Prevención del Delito"> Subdirección de Programas y Proyectos de Prevención del Delito </option>
                           <option value="Subdirección de Concertación Política y Atención Social"> Subdirección de Concertación Política y Atención Social </option>
                           <option value="Dirección Ejecutiva de Participación Ciudadana"> Dirección Ejecutiva de Participación Ciudadana </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Pueblos J"> Enlace de Participación y Gestión Ciudadana en Pueblos J  </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias A6"> Enlace de Participación y Gestión Ciudadana en Colonias A6 </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias B6"> Enlace de Participación y Gestión Ciudadana en Colonias B6 </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias C6"> Enlace de Participación y Gestión Ciudadana en Colonias C6 </option>
                           <option value="Enlace de Participación y Gestión Ciudadana en Colonias D6 "> Enlace de Participación y Gestión Ciudadana en Colonias D6 </option>
                           <option value="Dirección General de Planeación del Desarrollo"> Dirección General de Planeación del Desarrollo </option>
                           <option value="Coordinación de la Oficina de Transparencia ,Acceso a la Información, Datos Personales y Archivo "> Coordinación de la Oficina de Transparencia ,Acceso a la Información, Datos Personales y Archivo </option>
                           <option value="Jefatura de Unidad Departamental de Información Pública y Datos Personales "> Jefatura de Unidad Departamental de Información Pública y Datos Personales </option>
                           <option value="Jefatura de Unidad Departamental de Archivos"> Jefatura de Unidad Departamental de Archivos </option>
                           <option value="Dirección de Evaluación y Seguimiento"> Dirección de Evaluación y Seguimiento </option>
                           <option value="Subdirección de Evaluación"> Subdirección de Evaluación </option>
                           <option value="Jefatura de Unidad Departamental de Gestión"> Jefatura de Unidad Departamental de Gestión </option>
                           <option value="Jefatura de Unidad Departamental de Evaluación y Seguimiento de Programas Federales"> Jefatura de Unidad Departamental de Evaluación y Seguimiento de Programas Federales </option>
                           <option value="Jefatura de Unidad Departamental de Presupuesto Participativo "> Jefatura de Unidad Departamental de Presupuesto Participativo </option>
                           <option value="Jefatura de Unidad Departamental de Análisis Cualitativo y Cuantitativo"> Jefatura de Unidad Departamental de Análisis Cualitativo y Cuantitativo </option>
                           <option valuapellidome="Dirección de Proyectos de la Alcaldía"> Dirección de Proyectos de la Alcaldía </option>
                           <option value="Subdirección de Proyectos Federales de la Alcaldía"> Subdirección de Proyectos Federales de la Alcaldía </option>
                           <option value="Jefatura de Unidad Departamental de  Seguimiento de la Operación de Proyectos de Presupuesto Participativo "> Jefatura de Unidad Departamental de  Seguimiento de la Operación de Proyectos de Presupuesto Participativo </option>
                           <option value="Contraloría Interna en Tlalpan"> Contraloría Interna en Tlalpan </option>
                           <option value="Subdirección de Auditorías Operativas y Administrativas "> Subdirección de Auditorías Operativas y Administrativas </option>
                           <option value="Jefatura de Unidad Departamental de Auditorias Operativas y Administrativas A"> Jefatura de Unidad Departamental de Auditorias Operativas y Administrativas A </option>
                           <option value="Jefatura de Unidad Departamental de Auditorías Operativas y Administrativas B"> Jefatura de Unidad Departamental de Auditorías Operativas y AdministrativaJefatura de Unidad Departamental de Auditorías Operativas y Administrativas B </option>
                      </select>

                      </div>
                        <input class="btn btn-danger btn-rounded align-left" type="submit" name="guardar" value="Guardar" id="guardar">
        </div>
      </form>
      <!-- Footer -->

  </section>
  <footer class="page-footer font-small stylish-color-dark pt-4 fixed-bottom">
      <div class="footer-copyright text-center py-3">Tecnologias de la Informacion y Comunicaciones:
        <a href=""><img src="preters/img/logo_alcaldia.png" width="30px" alt=""> Alcaldia Tlalpan</a>
      </div>
  </footer>

    <!-- Footer -->
      <script type="text/javascript">
          $(document).ready(function(){
            //$('#lista1').val(2);
            recargarLista();

            $('#lista1').change(function(){
              recargarLista();
            });
          })
      </script>
      <script type="text/javascript">
          function recargarLista(){
            $.ajax({
              type:"POST",
              url:"php/dato.php",
              data:"area_edi=" + $('#lista1').val(),
              success:function(r){
                $('#segmento_ip').html(r);
              }
            });
          }
      </script>


  </body>
</html>
