<?php
session_start();
$varsession=$_SESSION['usuario1'];
if ($varsession == null || $varsession='') {
  header("Location:home.php");
  die();
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="preters/img/logo_alcaldia.png" type="image/png">
    <!-- Bootstrap CSS -->

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/estilos.css">
  </head>
  <body onpageshow="return false" oncontextmenu="return false" >

    <!-- HEADER -->
    <header style="margin:100px 0px 0px 0px;">
       <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
         <a class="navbar-brand" href="" id="titulo"><img src="preters/img/logo_alcaldia.png" alt="" width="33px">    Tecnologias De La Informacion y Comunicaciones</a>
         <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
           <span class="navbar-toggler-icon"></span>
         </button>
         <div class="collapse navbar-collapse" id="navbarCollapse">
           <form class="form-inline mt-2 mt-md-0">
             <input id="txt_bus" class="form-control mr-sm-2" type="text" placeholder="Buscar" aria-label="Search" name="buscar">
             <div id="header_btn">
               <a href="asing_ip.php"><button class="btn btn-outline-success my-2 my-sm-0" type="button" id="btn_in">Ingresar ip</button></a>
               <a href="cerrar_session.php"><button class="btn btn-outline-success my-2 my-sm-0" type="button" id="btn_cer">Cerrar Sesion</button></a>
             </div>
           </form>
         </div>
       </nav>
    </header>
    <!-- tabla -->
    <div class="contenedor" style="width:1590px;">
      <table class="table table-hover table-dark table_fixed" >
          <thead>
            <tr style="width:680px; text_align:center;">
              <th  scope="col" style="width:40px;">Id</th>
              <th  scope="col" style="width:200px;">Edificio</th>
              <th  scope="col" style="width:100px;">Ip</th>
              <th  scope="col" style="width:250px;">Descripcion</th>
              <th  scope="col" style="width:250px;">Informacion</th>
              <th  scope="col" style="width:150px;">Tipo de ip</th>
              <th  scope="col" style="width:300px;">Fecha de Asignacion</th>
              <th  scope="col" style="width:250px;">Modificaciones</th>
            </tr>
          </thead>
          <tbody>
            <?php require_once('php/rdatos.php'); ?>
          </tbody>
      </table>
    </div>
    <!-- Footer -->
    <footer class="navbar navbar-expand-md navbar-dark fixed-bottom bg-dark">
      <div id="btn_reg">
      </div>
      <label style="color:#fff; font-weight:bold; font-size:20px; margin-left: 1000px;">Bienvenido: </label>
    </footer>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
