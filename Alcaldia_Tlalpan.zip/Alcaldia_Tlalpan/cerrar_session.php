<?php

  session_start();

  $varsession=$_SESSION['usuario1'];
  if ($varsession == null || $varsession='') {
    header("Location:home.php");
    die();
  }

  session_destroy();
  header("Location:home.php")
 ?>
